version 1.0

# pipelines
import "germline_exome_hla_typing.wdl" as geht
import "rnaseq_star_fusion.wdl" as rsf
import "somatic_exome.wdl" as se
# others
import "subworkflows/phase_vcf.wdl" as pv
import "pvacsplice.wdl" as pspl
import "pvacseq.wdl" as p
import "subworkflows/generate_fda_metrics.wdl" as generate_fda_metrics
import "tools/extract_hla_alleles.wdl" as eha
import "tools/hla_consensus.wdl" as hc
import "tools/pvacfuse.wdl" as pf
import "types.wdl"  # !UnusedImport
import "tools/optitype_dna.wdl" as od
import "tools/phlat.wdl" as ph
import "tools/hlahd_dna.wdl" as hd
import "tools/concordance.wdl" as c
import "tools/wgs_regions_bed.wdl" as wrb

#
# These structs are needed only because MiniWDL, used by some of our
# scripts, has issues with Object types. We avoid this problem by
# enforcing struct boundaries to help the parser understand what we're
# doing.
#
# The reason to use these instead of primitives in outputs is
# to encode intended output directory for each file.
#

struct StarFusion {
  Array[File?] results
  PreliminaryStarFusionResults candidates_preliminary
}

struct Rnaseq {
  Array[File] alignments
  Array[File] stringtie_expression
  Array[File] kallisto_expression
  StarFusion star_fusion
  Array[File] fusioninspector_evidence
}

struct FdaMetricBundle {
  FdaMetrics unaligned_normal_dna
  FdaMetrics unaligned_tumor_dna
  FdaMetrics unaligned_tumor_rna
  FdaMetrics aligned_normal_dna
  FdaMetrics aligned_tumor_dna
  FdaMetrics aligned_tumor_rna
}

struct Qc {
  Array[File?] tumor_rna
  QCMetrics tumor_dna
  QCMetrics normal_dna
  Array[File?] concordance
  Array[File?] concordanceThreeway
  FdaMetricBundle fda_metrics
}

struct Variants {
  Array[File?] mutect
  Array[File?] strelka
  Array[File?] varscan
  Array[File?] docm
}

struct Cnv {
  Array[File?] cnvkit
}

struct Sv {
  Array[File?] manta
}

struct Somatic {
  Variants variants
  Array[File] final
  Cnv cnv
  Sv sv
}

struct Germline {
  Array[File?] variants
}

struct MHC {
  Array[File] mhc_i
  File? mhc_i_log
  Array[File] mhc_ii
  File? mhc_ii_log
  File? mhc_log
  Array[File] combined
  Array[File]? phase_vcf
  File? splice_transcript_combined_report
  File? splice_fasta
  File? splice_fasta_fai
  File? splice_gtf
  RegtoolsOutput? regtools_output
}

workflow immuno {
  input {

    # --------- RNAseq Inputs ------------------------------------------

    File reference_annotation
    Array[SequenceData] rna_sequence
    String sample_name

    File trimming_adapters
    String trimming_adapter_trim_end
    Int trimming_adapter_min_overlap
    Int trimming_max_uncalled
    Int trimming_min_readlength

    File kallisto_index
    File gene_transcript_lookup_table
    String? strand  # [first, second, unstranded]
    File refFlat
    File ribosomal_intervals
    File star_fusion_genome_dir_zip
    Boolean examine_coding_effect = true
    String? fusioninspector_mode  # enum [inspect validate]
    File cdna_fasta
    File agfusion_database
    Boolean agfusion_annotate_noncanonical = true
    Float? min_ffpm_level = 0.05

    # --------- Somatic Exome Inputs -----------------------------------

    File reference
    File reference_fai
    File reference_dict
    File reference_alt
    File reference_amb
    File reference_ann
    File reference_bwt
    File reference_pac
    File reference_0123

    String tumor_name = "tumor"
    String tumor_sample_name
    Array[SequenceData] tumor_sequence

    String normal_name = "normal"
    String normal_sample_name
    Array[SequenceData] normal_sequence

    Array[File] bqsr_known_sites
    Array[File] bqsr_known_sites_tbi
    File bait_intervals
    File target_intervals
    # WGS mode: tumor/normal DNA is whole-genome. After alignment, keep only
    # read templates with a primary or supplementary alignment within wgs_region_padding of the
    # bait or target intervals, in the MHC, on HLA/chr6 alt contigs, or fully
    # unmapped; everything downstream then sees exome-sized BAMs.
    Boolean wgs_mode = false
    Int wgs_region_padding = 250
    Int target_interval_padding = 100
    Array[LabelledFile] per_base_intervals
    Array[LabelledFile] per_target_intervals
    Array[LabelledFile] summary_intervals

    File omni_vcf
    File omni_vcf_tbi

    String picard_metric_accumulation_level
    Int qc_minimum_mapping_quality = 0
    Int qc_minimum_base_quality = 0

    Int strelka_cpu_reserved = 8
    Int scatter_count = 50

    Int? varscan_strand_filter
    Int? varscan_min_coverage
    Float? varscan_min_var_freq
    Float? varscan_p_value
    Float? varscan_max_normal_freq

    Float? fp_min_var_freq

    File docm_vcf
    File docm_vcf_tbi

    Boolean filter_docm_variants = true

    String? gnomad_field_name
    Float? filter_gnomADe_maximum_population_allele_frequency

    File vep_cache_dir_zip
    String vep_ensembl_assembly
    String vep_ensembl_version
    String vep_ensembl_species
    File? synonyms_file
    Boolean annotate_coding_only = false
    # one of [pick, flag_pick, pick-allele, per_gene, pick_allele_gene, flag_pick_allele, flag_pick_allele_gene]
    String? vep_pick
    Boolean cle_vcf_filter = false
    
    Float? filter_somatic_llr_threshold
    Float? filter_somatic_llr_tumor_purity
    Float? filter_somatic_llr_normal_contamination_rate

    Array[String] vep_to_table_fields = ["HGVSc", "HGVSp"]
    Array[String] variants_to_table_genotype_fields = ["GT", "AD"]
    Array[String] variants_to_table_fields = ["CHROM", "POS", "ID", "REF", "ALT", "set", "AC", "AF"]
    Array[VepCustomAnnotation] vep_custom_annotations

    File? manta_call_regions
    File? manta_call_regions_tbi
    Boolean manta_non_wgs = true
    Boolean? manta_output_contigs

    File somalier_vcf
    File? validated_variants
    File? validated_variants_tbi

    Int? max_mm_qualsum_diff
    Int? max_var_mm_qualsum

    # --------- Germline Inputs ----------------------------------------

    Array[String] gvcf_gq_bands
    Array[Array[String]] gatk_haplotypecaller_intervals
    Int? ploidy
    String? optitype_name
    Float germline_filter_gnomAD_maximum_population_allele_frequency = 1.1
    String? coding_filter

    # --------- Phase VCF Inputs ---------------------------------------


    # --------- HLA Consensus Inputs -----------------------------------
    Array[String]? clinical_mhc_classI_alleles
    Array[String]? clinical_mhc_classII_alleles
    String hla_source_mode

    # --------- PVACseq Inputs -----------------------------------------
    Int? readcount_minimum_base_quality
    Int? readcount_minimum_mapping_quality
    Array[String] prediction_algorithms
    Array[Int]? epitope_lengths_class_i
    Array[Int]? epitope_lengths_class_ii
    Int? binding_threshold
    Float? binding_percentile_threshold
    Float? presentation_percentile_threshold
    Float? immunogenicity_percentile_threshold
    String? percentile_threshold_strategy
    Float? minimum_fold_change
    String? top_score_metric  # enum [lowest, median]
    Array[String]? top_score_metric2
    String? additional_report_columns  # enum [sample_name]
    Int? fasta_size
    Int? downstream_sequence_length
    Boolean? exclude_nas
    Array[String]? transcript_prioritization_strategy # allowed values ['canonical', 'mane_select', 'tsl']
    Int? maximum_transcript_support_level  # enum [1 2 3 4 5]
    Int? normal_cov
    Int? tdna_cov
    Int? trna_cov
    Float? normal_vaf
    Float? tdna_vaf
    Float? trna_vaf
    Float? expn_val
    String? net_chop_method  # enum [cterm 20s]
    Float? net_chop_threshold
    Boolean? netmhc_stab
    Boolean? run_reference_proteome_similarity
    File? peptide_fasta
    File? genes_of_interest_file
    Int? pvacseq_threads
    Int? iedb_retries
    String? netmhciipan_version # enum [4.3, 4.2, 4.1, 4.0]
    Boolean? pvacfuse_keep_tmp_files
    Float? tumor_purity
    Boolean? allele_specific_binding_thresholds
    Int? aggregate_inclusion_binding_threshold
    Int? aggregate_inclusion_count_limit
    Array[String]? problematic_amino_acids
    Boolean? allele_specific_anchors
    Float? anchor_contribution_threshold
    Int? pvacfuse_read_support
    Float? pvacfuse_expn_val
    Array[String]? biotypes
    Boolean? allow_incomplete_transcripts
    Boolean? use_normalized_percentiles
    File? reference_scores_zip
    Boolean? run_ml_predictions
    Float? ml_threshold_accept
    Float? ml_threshold_reject


    # --------- PVACsplice Inputs -----------------------------------------
    # Note: variables similar to PVACseq Inputs or other sections Inputs won't be listed here.
    String? regtools_output_filename_tsv
    String? regtools_output_filename_vcf
    String? regtools_output_filename_bed
    Int? regtools_window_size
    Int? max_distance_exon 
    Int? max_distance_intron
    Boolean annotate_intronic_variant = false
    Boolean annotate_exonic_variant = false
    Boolean not_skipping_single_exon_transcripts = false
    Boolean singecell_barcode = false
    Boolean intron_motif_priority = false
    Int? pvacsplice_threads
    Int? junction_score
    Int? variant_distance
    Boolean? save_gtf
    Array[String]? junction_anchor_types
    Boolean? pvacsplice_keep_tmp_files


    # --------- FDA metrics inputs -------------------------------------
    String? reference_genome_name
    String? dna_sequencing_platform
    String? dna_sequencing_instrument
    String? dna_sequencing_kit
    String? dna_sequencing_type
    String? dna_single_or_paired_end
    String? normal_dna_spike_in_error_rate
    String? tumor_dna_spike_in_error_rate
    String? normal_dna_total_dna
    String? tumor_dna_total_dna
    String? rna_sequencing_platform
    String? rna_sequencing_instrument
    String? rna_sequencing_kit
    String? rna_sequencing_type
    String? rna_single_or_paired_end
    String? rna_spike_in_error_rate
    String? rna_total_rna
    String? rna_rin_score
    String? rna_freq_normalization_method
    String? rna_annotation_file
  }

  call rsf.rnaseqStarFusion as rna {
    input:
    reference=reference,
    reference_fai=reference_fai,
    reference_dict=reference_dict,
    reference_annotation=reference_annotation,
    unaligned=rna_sequence,
    sample_name=sample_name,
    trimming_adapters=trimming_adapters,
    trimming_adapter_trim_end=trimming_adapter_trim_end,
    trimming_adapter_min_overlap=trimming_adapter_min_overlap,
    trimming_max_uncalled=trimming_max_uncalled,
    trimming_min_readlength=trimming_min_readlength,
    kallisto_index=kallisto_index,
    gene_transcript_lookup_table=gene_transcript_lookup_table,
    strand=strand,
    refFlat=refFlat,
    ribosomal_intervals=ribosomal_intervals,
    star_fusion_genome_dir_zip=star_fusion_genome_dir_zip,
    examine_coding_effect=examine_coding_effect,
    fusioninspector_mode=fusioninspector_mode,
    cdna_fasta=cdna_fasta,
    agfusion_database=agfusion_database,
    agfusion_annotate_noncanonical=agfusion_annotate_noncanonical,
    min_ffpm_level=min_ffpm_level
  }

  if (wgs_mode) {
    call wrb.wgsRegionsBed {
      input:
      interval_lists=[bait_intervals, target_intervals],
      reference_dict=reference_dict,
      padding=wgs_region_padding,
      min_padding=target_interval_padding
    }
  }

  call se.somaticExome {
    input:
    reference=reference,
    reference_fai=reference_fai,
    reference_dict=reference_dict,
    reference_alt=reference_alt,
    reference_amb=reference_amb,
    reference_ann=reference_ann,
    reference_bwt=reference_bwt,
    reference_pac=reference_pac,
    reference_0123=reference_0123,
    tumor_sequence=tumor_sequence,
    restrict_to_bed=wgsRegionsBed.regions_bed,
    # Filtered WGS has no reads in CNVkit's hybrid-mode antitarget bins.
    cnvkit_method=if wgs_mode then "amplicon" else "hybrid",
    tumor_name=tumor_name,
    normal_sequence=normal_sequence,
    normal_name=normal_name,
    bqsr_known_sites=bqsr_known_sites,
    bqsr_known_sites_tbi=bqsr_known_sites_tbi,
    bait_intervals=bait_intervals,
    target_intervals=target_intervals,
    target_interval_padding=target_interval_padding,
    per_base_intervals=per_base_intervals,
    per_target_intervals=per_target_intervals,
    summary_intervals=summary_intervals,
    gnomad_field_name=gnomad_field_name,
    filter_gnomADe_maximum_population_allele_frequency=filter_gnomADe_maximum_population_allele_frequency,
    omni_vcf=omni_vcf,
    omni_vcf_tbi=omni_vcf_tbi,
    picard_metric_accumulation_level=picard_metric_accumulation_level,
    qc_minimum_mapping_quality=qc_minimum_mapping_quality,
    qc_minimum_base_quality=qc_minimum_base_quality,
    strelka_cpu_reserved=strelka_cpu_reserved,
    scatter_count=scatter_count,
    varscan_strand_filter=varscan_strand_filter,
    varscan_min_coverage=varscan_min_coverage,
    varscan_min_var_freq=varscan_min_var_freq,
    varscan_p_value=varscan_p_value,
    varscan_max_normal_freq=varscan_max_normal_freq,
    fp_min_var_freq=fp_min_var_freq,
    docm_vcf=docm_vcf,
    docm_vcf_tbi=docm_vcf_tbi,
    filter_docm_variants=filter_docm_variants,
    vep_cache_dir_zip=vep_cache_dir_zip,
    vep_ensembl_assembly=vep_ensembl_assembly,
    vep_ensembl_version=vep_ensembl_version,
    vep_ensembl_species=vep_ensembl_species,
    synonyms_file=synonyms_file,
    annotate_coding_only=annotate_coding_only,
    vep_pick=vep_pick,
    cle_vcf_filter=cle_vcf_filter,
    filter_somatic_llr_threshold=filter_somatic_llr_threshold,
    filter_somatic_llr_tumor_purity=filter_somatic_llr_tumor_purity,
    filter_somatic_llr_normal_contamination_rate=filter_somatic_llr_normal_contamination_rate,
    variants_to_table_fields=variants_to_table_fields,
    variants_to_table_genotype_fields=variants_to_table_genotype_fields,
    vep_to_table_fields=vep_to_table_fields,
    vep_custom_annotations=vep_custom_annotations,
    manta_call_regions=manta_call_regions,
    manta_call_regions_tbi=manta_call_regions_tbi,
    manta_non_wgs=manta_non_wgs,
    manta_output_contigs=manta_output_contigs,
    somalier_vcf=somalier_vcf,
    tumor_sample_name=tumor_sample_name,
    normal_sample_name=normal_sample_name,
    validated_variants=validated_variants,
    validated_variants_tbi=validated_variants_tbi,
    max_mm_qualsum_diff=max_mm_qualsum_diff,
    max_var_mm_qualsum=max_var_mm_qualsum
  }

  # In wgs_mode, germline calling reuses the normal alignment from
  # somaticExome (same sequenceToBqsr and qcExome inputs) instead of
  # aligning the whole genome a second time.
  if (wgs_mode) {
    File wgs_normal_bam = somaticExome.normal_bam
    File wgs_normal_bam_bai = somaticExome.normal_bam_bai
    File wgs_normal_mark_duplicates_metrics = somaticExome.normal_mark_duplicates_metrics
    QCMetrics wgs_normal_qc_metrics = somaticExome.normal_qc_metrics
  }

  call geht.germlineExomeHlaTyping as germlineExome {
    input:
    reference=reference,
    reference_fai=reference_fai,
    reference_dict=reference_dict,
    reference_alt=reference_alt,
    reference_amb=reference_amb,
    reference_ann=reference_ann,
    reference_bwt=reference_bwt,
    reference_pac=reference_pac,
    reference_0123=reference_0123,
    sequence=normal_sequence,
    restrict_to_bed=wgsRegionsBed.regions_bed,
    aligned_bam=wgs_normal_bam,
    aligned_bam_bai=wgs_normal_bam_bai,
    aligned_mark_duplicates_metrics=wgs_normal_mark_duplicates_metrics,
    aligned_qc_metrics=wgs_normal_qc_metrics,
    bqsr_known_sites=bqsr_known_sites,
    bqsr_known_sites_tbi=bqsr_known_sites_tbi,
    bait_intervals=bait_intervals,
    target_intervals=target_intervals,
    target_interval_padding=target_interval_padding,
    per_base_intervals=per_base_intervals,
    per_target_intervals=per_target_intervals,
    summary_intervals=summary_intervals,
    omni_vcf=omni_vcf,
    omni_vcf_tbi=omni_vcf_tbi,
    picard_metric_accumulation_level=picard_metric_accumulation_level,
    gvcf_gq_bands=gvcf_gq_bands,
    intervals=gatk_haplotypecaller_intervals,
    ploidy=ploidy,
    vep_cache_dir_zip=vep_cache_dir_zip,
    vep_ensembl_assembly=vep_ensembl_assembly,
    vep_ensembl_version=vep_ensembl_version,
    vep_ensembl_species=vep_ensembl_species,
    vep_custom_annotations=vep_custom_annotations,
    synonyms_file=synonyms_file,
    annotate_coding_only=annotate_coding_only,
    qc_minimum_mapping_quality=qc_minimum_mapping_quality,
    qc_minimum_base_quality=qc_minimum_base_quality,
    optitype_name="optitype_normal",
    germline_filter_gnomAD_maximum_population_allele_frequency=germline_filter_gnomAD_maximum_population_allele_frequency,
    coding_filter=coding_filter
  }

  call c.concordance as concordanceThreeway {
    input:
      reference = reference,
      reference_fai = reference_fai,
      reference_dict = reference_dict,
      vcf = somalier_vcf,
      bams = [somaticExome.tumor_cram, somaticExome.normal_cram, rna.final_bam],
      bais = [somaticExome.tumor_cram_crai, somaticExome.normal_cram_crai, rna.final_bam_bai]
  }

  call od.optitypeDna as optitype {
    input: 
    optitype_name="optitype_tumor",
    reference=reference,
    reference_fai=reference_fai,
    cram=somaticExome.tumor_cram,
    cram_crai=somaticExome.tumor_cram_crai,
  }


  call hd.hlahdDna as hlahd {
    input:
    reference=reference,
    reference_fai=reference_fai,
    cram=somaticExome.tumor_cram,
    cram_crai=somaticExome.tumor_cram_crai,
    hlahd_name="hlahd_tumor"
  }

  call ph.phlat {
    input:
    phlat_name="phlat_tumor",
    cram=somaticExome.tumor_cram,
    cram_crai=somaticExome.tumor_cram_crai,
    reference=reference,
    reference_fai=reference_fai
  } 

  

  call pv.phaseVcf {
    input:
    somatic_vcf=somaticExome.final_filtered_vcf,
    somatic_vcf_tbi=somaticExome.final_filtered_vcf_tbi,
    germline_vcf=germlineExome.final_vcf,
    reference=reference,
    reference_fai=reference_fai,
    reference_dict=reference_dict,
    bam=somaticExome.tumor_cram,
    bam_bai=somaticExome.tumor_cram_crai,
    normal_sample_name=normal_sample_name,
    tumor_sample_name=tumor_sample_name
  }

  call eha.extractHlaAlleles as extractAlleles {
    input:
    optitype_file=germlineExome.optitype_tsv, 
    phlat_file=germlineExome.phlat_summary, 
    hlahd_file=germlineExome.hlahd_result_txt
  }

  call hc.hlaConsensus {
    input:
    hla_source_mode=hla_source_mode,
    hla_alleles=extractAlleles.allele_string,
    clinical_mhc_classI_alleles=clinical_mhc_classI_alleles,
    clinical_mhc_classII_alleles=clinical_mhc_classII_alleles
  }

  call p.pvacseq {
    input:
    detect_variants_vcf=somaticExome.final_filtered_vcf,
    detect_variants_vcf_tbi=somaticExome.final_filtered_vcf_tbi,
    sample_name=tumor_sample_name,
    normal_sample_name=normal_sample_name,
    rnaseq_bam=rna.final_bam,
    rnaseq_bam_bai=rna.final_bam_bai,
    reference=reference,
    reference_fai=reference_fai,
    reference_dict=reference_dict,
    readcount_minimum_base_quality=readcount_minimum_base_quality,
    readcount_minimum_mapping_quality=readcount_minimum_mapping_quality,
    gene_expression_file=rna.kallisto_gene_abundance,
    transcript_expression_file=rna.kallisto_transcript_abundance_tsv,
    alleles=hlaConsensus.consensus_alleles,
    prediction_algorithms=prediction_algorithms,
    epitope_lengths_class_i=epitope_lengths_class_i,
    epitope_lengths_class_ii=epitope_lengths_class_ii,
    binding_threshold=binding_threshold,
    binding_percentile_threshold=binding_percentile_threshold,
    presentation_percentile_threshold=presentation_percentile_threshold,
    immunogenicity_percentile_threshold=immunogenicity_percentile_threshold,
    percentile_threshold_strategy=percentile_threshold_strategy,
    minimum_fold_change=minimum_fold_change,
    top_score_metric=top_score_metric,
    top_score_metric2=top_score_metric2,
    additional_report_columns=additional_report_columns,
    fasta_size=fasta_size,
    downstream_sequence_length=downstream_sequence_length,
    exclude_nas=exclude_nas,
    phased_proximal_variants_vcf=phaseVcf.phased_vcf,
    phased_proximal_variants_vcf_tbi=phaseVcf.phased_vcf_tbi,
    transcript_prioritization_strategy=transcript_prioritization_strategy,
    maximum_transcript_support_level=maximum_transcript_support_level,
    normal_cov=normal_cov,
    tdna_cov=tdna_cov,
    trna_cov=trna_cov,
    normal_vaf=normal_vaf,
    tdna_vaf=tdna_vaf,
    trna_vaf=trna_vaf,
    expn_val=expn_val,
    net_chop_method=net_chop_method,
    net_chop_threshold=net_chop_threshold,
    netmhc_stab=netmhc_stab,
    run_reference_proteome_similarity=run_reference_proteome_similarity,
    peptide_fasta=peptide_fasta,
    genes_of_interest_file=genes_of_interest_file,
    n_threads=pvacseq_threads,
    netmhciipan_version=netmhciipan_version,
    iedb_retries=iedb_retries,
    variants_to_table_fields=variants_to_table_fields,
    variants_to_table_genotype_fields=variants_to_table_genotype_fields,
    vep_to_table_fields=vep_to_table_fields,
    prefix="variants.final",
    tumor_purity=tumor_purity,
    allele_specific_binding_thresholds=allele_specific_binding_thresholds,
    aggregate_inclusion_binding_threshold=aggregate_inclusion_binding_threshold,
    aggregate_inclusion_count_limit=aggregate_inclusion_count_limit,
    problematic_amino_acids=problematic_amino_acids,
    allele_specific_anchors=allele_specific_anchors,
    anchor_contribution_threshold=anchor_contribution_threshold,
    biotypes=biotypes,
    allow_incomplete_transcripts=allow_incomplete_transcripts,
    use_normalized_percentiles=use_normalized_percentiles,
    reference_scores_zip=reference_scores_zip,
    run_ml_predictions=run_ml_predictions,
    ml_threshold_accept=ml_threshold_accept,
    ml_threshold_reject=ml_threshold_reject
  }

  call pspl.pvacsplice {
    input: 
    #### prep files
    detect_variants_vcf=somaticExome.final_filtered_vcf,
    detect_variants_vcf_tbi=somaticExome.final_filtered_vcf_tbi,
    sample_name=tumor_sample_name,
    normal_sample_name=normal_sample_name,
    rnaseq_bam=rna.final_bam,
    rnaseq_bam_bai=rna.final_bam_bai,
    reference=reference,
    reference_fai=reference_fai,
    reference_dict=reference_dict,
    peptide_fasta=peptide_fasta,
    genes_of_interest_file=genes_of_interest_file,
    readcount_minimum_base_quality=readcount_minimum_base_quality,
    readcount_minimum_mapping_quality=readcount_minimum_mapping_quality,
    gene_expression_file=rna.kallisto_gene_abundance,
    transcript_expression_file=rna.kallisto_transcript_abundance_tsv,
    #expression_tool=expression_tool #if add this, also add the following line to input section : String expression_tool = "kallisto" 
    #### REGTOOLS inputs : 
    output_filename_tsv=regtools_output_filename_tsv,
    output_filename_vcf=regtools_output_filename_vcf,
    output_filename_bed=regtools_output_filename_bed,
    strand=strand, #might consider using the output of task 'rna' for strand info instead
    window_size=regtools_window_size,
    max_distance_exon=max_distance_exon, 
    max_distance_intron=max_distance_intron,
    annotate_intronic_variant=annotate_intronic_variant, 
    annotate_exonic_variant=annotate_exonic_variant, 
    not_skipping_single_exon_transcripts=not_skipping_single_exon_transcripts, 
    singecell_barcode=singecell_barcode, 
    intron_motif_priority=intron_motif_priority,
    reference_annotation=reference_annotation,
    #### PVACSPLICE inputs :
    alleles=hlaConsensus.consensus_alleles,
    prediction_algorithms=prediction_algorithms,
    epitope_lengths_class_i=epitope_lengths_class_i,
    epitope_lengths_class_ii=epitope_lengths_class_ii,
    binding_threshold=binding_threshold,
    binding_percentile_threshold=binding_percentile_threshold,
    presentation_percentile_threshold=presentation_percentile_threshold,
    immunogenicity_percentile_threshold=immunogenicity_percentile_threshold,
    percentile_threshold_strategy=percentile_threshold_strategy,
    iedb_retries=iedb_retries,
    top_score_metric=top_score_metric,
    top_score_metric2=top_score_metric2,
    additional_report_columns=additional_report_columns,
    fasta_size=fasta_size,
    exclude_nas=exclude_nas,
    maximum_transcript_support_level=maximum_transcript_support_level,
    normal_cov=normal_cov,
    tdna_cov=tdna_cov,
    trna_cov=trna_cov,
    normal_vaf=normal_vaf,
    tdna_vaf=tdna_vaf,
    trna_vaf=trna_vaf,
    expn_val=expn_val,
    net_chop_method=net_chop_method,
    net_chop_threshold=net_chop_threshold,
    netmhc_stab=netmhc_stab,
    run_reference_proteome_similarity=run_reference_proteome_similarity,
    n_threads=pvacsplice_threads,
    netmhciipan_version=netmhciipan_version,
    tumor_purity=tumor_purity,
    allele_specific_binding_thresholds=allele_specific_binding_thresholds,
    aggregate_inclusion_binding_threshold=aggregate_inclusion_binding_threshold,
    problematic_amino_acids=problematic_amino_acids,
    biotypes=biotypes,
    allow_incomplete_transcripts=allow_incomplete_transcripts,
    aggregate_inclusion_count_limit=aggregate_inclusion_count_limit,
    junction_score=junction_score,
    variant_distance=variant_distance,
    save_gtf=save_gtf,
    junction_anchor_types=junction_anchor_types,
    keep_tmp_files=pvacsplice_keep_tmp_files
  }

  call pf.pvacfuse {
    input:
    input_fusions_zip=rna.annotated_fusion_predictions_zip,
    star_fusion_file=rna.star_fusion_abridge,
    sample_name=tumor_sample_name,
    alleles=hlaConsensus.consensus_alleles,
    prediction_algorithms=prediction_algorithms,
    epitope_lengths_class_i=epitope_lengths_class_i,
    epitope_lengths_class_ii=epitope_lengths_class_ii,
    binding_threshold=binding_threshold,
    binding_percentile_threshold=binding_percentile_threshold,
    presentation_percentile_threshold=presentation_percentile_threshold,
    immunogenicity_percentile_threshold=immunogenicity_percentile_threshold,
    percentile_threshold_strategy=percentile_threshold_strategy,
    keep_tmp_files=pvacfuse_keep_tmp_files,
    net_chop_method=net_chop_method,
    netmhc_stab=netmhc_stab,
    top_score_metric=top_score_metric,
    top_score_metric2=top_score_metric2,
    net_chop_threshold=net_chop_threshold,
    run_reference_proteome_similarity=run_reference_proteome_similarity,
    peptide_fasta=peptide_fasta,
    genes_of_interest_file=genes_of_interest_file,
    additional_report_columns=additional_report_columns,
    fasta_size=fasta_size,
    downstream_sequence_length=downstream_sequence_length,
    exclude_nas=exclude_nas,
    n_threads=pvacseq_threads,
    iedb_retries=iedb_retries,
    netmhciipan_version=netmhciipan_version,
    read_support=pvacfuse_read_support,
    expn_val=pvacfuse_expn_val,
    allele_specific_binding_thresholds=allele_specific_binding_thresholds,
    aggregate_inclusion_binding_threshold=aggregate_inclusion_binding_threshold,
    aggregate_inclusion_count_limit=aggregate_inclusion_count_limit,
    problematic_amino_acids=problematic_amino_acids,
    use_normalized_percentiles=use_normalized_percentiles,
    reference_scores_zip=reference_scores_zip
  }

  call generate_fda_metrics.generateFdaMetrics {
    input:
      reference = reference,
      reference_dict = reference_dict,
      reference_index = reference_fai,

      unaligned_normal_dna = normal_sequence,
      unaligned_tumor_dna = tumor_sequence,
      unaligned_tumor_rna = rna_sequence,
      aligned_normal_dna = somaticExome.normal_cram,
      aligned_normal_dna_index = somaticExome.normal_cram_crai,
      aligned_tumor_dna = somaticExome.tumor_cram,
      aligned_tumor_dna_index = somaticExome.tumor_cram_crai,
      aligned_tumor_rna = rna.final_bam,

      normal_qc_metrics = somaticExome.normal_qc_metrics,
      normal_duplication_metrics = somaticExome.normal_mark_duplicates_metrics,
      tumor_qc_metrics = somaticExome.tumor_qc_metrics,
      tumor_duplication_metrics = somaticExome.tumor_mark_duplicates_metrics,
      rna_metrics = rna.metrics,

      reference_genome = reference_genome_name,
      dna_sequencing_platform = dna_sequencing_platform,
      dna_sequencing_instrument = dna_sequencing_instrument,
      dna_sequencing_kit = dna_sequencing_kit,
      dna_sequencing_type = dna_sequencing_type,
      dna_single_or_paired_end = dna_single_or_paired_end,
      normal_dna_spike_in_error_rate = normal_dna_spike_in_error_rate,
      tumor_dna_spike_in_error_rate = tumor_dna_spike_in_error_rate,
      normal_dna_total_dna = normal_dna_total_dna,
      tumor_dna_total_dna = tumor_dna_total_dna,
      normal_dna_sample_name = normal_sample_name,
      tumor_dna_sample_name = tumor_sample_name,
      rna_sequencing_platform = rna_sequencing_platform,
      rna_sequencing_instrument = rna_sequencing_instrument,
      rna_sequencing_kit = rna_sequencing_kit,
      rna_sequencing_type = rna_sequencing_type ,
      rna_single_or_paired_end = rna_single_or_paired_end,
      rna_spike_in_error_rate = rna_spike_in_error_rate,
      rna_total_rna = rna_total_rna,
      rna_rin_score = rna_rin_score,
      rna_freq_normalization_method = rna_freq_normalization_method,
      rna_annotation_file = rna_annotation_file,
      rna_sample_name = sample_name
  }

  output {
    # ---------- RNAseq Outputs ----------------------------------------
    Rnaseq rnaseq = object {
      alignments: [
        rna.final_bam,
        rna.final_bam_bai,
        pvacseq.indel_counting_bam,
        pvacseq.indel_counting_bai
      ],
      stringtie_expression: [
        rna.stringtie_transcript_gtf,
        rna.stringtie_gene_expression_tsv
      ],
      kallisto_expression: [
        rna.kallisto_transcript_abundance_tsv,
        rna.kallisto_transcript_abundance_h5,
        rna.kallisto_gene_abundance,
        rna.kallisto_fusion_evidence
      ],
      star_fusion: object {
        results: [
          rna.star_fusion_out,
          rna.star_junction_out,
          rna.star_fusion_predict,
          rna.star_fusion_abridge,
          rna.star_fusion_coding_region_effects,
          rna.annotated_fusion_predictions_zip
        ],
        candidates_preliminary: rna.prelim_starfusion_results
      },
      fusioninspector_evidence: rna.fusioninspector_evidence
    }

    # -------- QC Outputs -----------------------------------------

    Qc qc =  object {
      tumor_rna: flatten([
        [ rna.metrics, 
          rna.chart,
          rna.flagstats ],
        rna.strand_info  
      ]),
      tumor_dna: somaticExome.tumor_qc_metrics,
      normal_dna: somaticExome.normal_qc_metrics,
      concordance: [
        somaticExome.somalier_concordance_metrics,
        somaticExome.somalier_concordance_statistics
      ],
      concordanceThreeway: [
        concordanceThreeway.somalier_pairs,
        concordanceThreeway.somalier_samples
      ],  
      fda_metrics: object {
        unaligned_normal_dna: generateFdaMetrics.unaligned_normal_dna_metrics,
        unaligned_tumor_dna: generateFdaMetrics.unaligned_tumor_dna_metrics,
        unaligned_tumor_rna: generateFdaMetrics.unaligned_tumor_rna_metrics,
        aligned_normal_dna: generateFdaMetrics.aligned_normal_dna_metrics,
        aligned_tumor_dna: generateFdaMetrics.aligned_tumor_dna_metrics,
        aligned_tumor_rna: generateFdaMetrics.aligned_tumor_rna_metrics
      }
    }

    # -------- Somatic Outputs -----------------------------------------

    File tumor_cram = somaticExome.tumor_cram
    File tumor_cram_crai = somaticExome.tumor_cram_crai
    File normal_cram = somaticExome.normal_cram
    File normal_cram_crai = somaticExome.normal_cram_crai

    Somatic somatic = object {
      variants: object {
        mutect: [
          somaticExome.mutect_unfiltered_vcf,
          somaticExome.mutect_unfiltered_vcf_tbi,
          somaticExome.mutect_filtered_vcf,
          somaticExome.mutect_filtered_vcf_tbi
        ],
        strelka: [
          somaticExome.strelka_unfiltered_vcf,
          somaticExome.strelka_unfiltered_vcf_tbi,
          somaticExome.strelka_filtered_vcf,
          somaticExome.strelka_filtered_vcf_tbi
        ],
        varscan: [
          somaticExome.varscan_unfiltered_vcf,
          somaticExome.varscan_unfiltered_vcf_tbi,
          somaticExome.varscan_filtered_vcf,
          somaticExome.varscan_filtered_vcf_tbi,
        ],
        docm: [
          somaticExome.docm_filtered_vcf,
          somaticExome.docm_filtered_vcf_tbi
        ],
      },
      final: [
        somaticExome.final_vcf,
        somaticExome.final_vcf_tbi,
        somaticExome.final_filtered_vcf,
        somaticExome.final_filtered_vcf_tbi,
        somaticExome.final_tsv
      ],
      cnv: object {cnvkit: [
        somaticExome.intervals_antitarget,
        somaticExome.intervals_target,
        somaticExome.normal_antitarget_coverage,
        somaticExome.normal_target_coverage,
        somaticExome.reference_coverage,
        somaticExome.cn_diagram,
        somaticExome.cn_scatter_plot,
        somaticExome.tumor_antitarget_coverage,
        somaticExome.tumor_target_coverage,
        somaticExome.tumor_bin_level_ratios,
        somaticExome.tumor_segmented_ratios
      ]},
      sv: object {manta: [
        somaticExome.diploid_variants,
        somaticExome.diploid_variants_tbi,
        somaticExome.somatic_variants,
        somaticExome.somatic_variants_tbi,
        somaticExome.all_candidates,
        somaticExome.all_candidates_tbi,
        somaticExome.small_candidates,
        somaticExome.small_candidates_tbi,
        somaticExome.tumor_only_variants,
        somaticExome.tumor_only_variants_tbi
      ]}
    }

    # ---------- Germline Outputs --------------------------------------

    Germline germline = object {
      variants: [
        germlineExome.final_vcf,
        germlineExome.final_vcf_tbi,
        germlineExome.filtered_vcf,
        germlineExome.filtered_vcf_tbi,
        germlineExome.vep_summary
      ]
    }

    Array[File] hla_typing = flatten([
      [germlineExome.optitype_tsv,
       germlineExome.optitype_plot,
       optitype.optitype_tsv,
       optitype.optitype_plot,
       hlahd.hlahd_result_txt,
       germlineExome.hlahd_result_txt,
       germlineExome.phlat_summary,
       phlat.phlat_summary,
       extractAlleles.allele_file,
       hlaConsensus.consensus_alleles_file],
      hlaConsensus.hla_call_files
    ])


    # --------- pVACtools Outputs ------------------------------------------

    MHC pVACseq = object {
      mhc_i: pvacseq.mhc_i,
      mhc_i_log: pvacseq.mhc_i_log,
      mhc_ii: pvacseq.mhc_ii,
      mhc_ii_log: pvacseq.mhc_ii_log,
      combined: pvacseq.combined,
      phase_vcf: [phaseVcf.phased_vcf, phaseVcf.phased_vcf_tbi]
    }

    MHC pVACfuse = object {
      mhc_i: pvacfuse.mhc_i,
      mhc_i_log: pvacfuse.mhc_i_log,
      mhc_ii: pvacfuse.mhc_ii,
      mhc_ii_log: pvacfuse.mhc_ii_log,
      combined: pvacfuse.combined
    }

    MHC pVACsplice = object {
      mhc_i: pvacsplice.mhc_i,
      mhc_i_log: pvacsplice.mhc_i_log,
      mhc_ii: pvacsplice.mhc_ii,
      mhc_ii_log: pvacsplice.mhc_ii_log,
      mhc_log: pvacsplice.mhc_log,
      combined: pvacsplice.combined,
      regtools_output: pvacsplice.regtools_output,
      splice_transcript_combined_report: pvacsplice.splice_transcript_combined_report,
      splice_fasta: pvacsplice.splice_fasta,
      splice_fasta_fai: pvacsplice.splice_fasta_fai,
      splice_gtf : pvacsplice.splice_gtf
    }


    File pvacseq_annotated_expression_vcf_gz = pvacseq.annotated_vcf
    File pvacseq_annotated_expression_vcf_gz_tbi = pvacseq.annotated_vcf_tbi
    File variants_final_annotated_tsv = pvacseq.annotated_tsv


  }
}
